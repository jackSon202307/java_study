package com.itheima.dao;

public interface UserDao {


    void show();

}
