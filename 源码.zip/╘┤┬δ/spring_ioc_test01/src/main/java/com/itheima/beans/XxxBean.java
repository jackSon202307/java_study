package com.itheima.beans;

import com.itheima.anno.MyComponent;

@MyComponent("xxx")
public class XxxBean {
}
