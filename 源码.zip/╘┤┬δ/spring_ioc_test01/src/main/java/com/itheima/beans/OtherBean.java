package com.itheima.beans;


import com.itheima.anno.MyComponent;

@MyComponent("otherBean")
public class OtherBean {
}
