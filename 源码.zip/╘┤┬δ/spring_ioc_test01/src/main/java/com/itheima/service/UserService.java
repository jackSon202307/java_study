package com.itheima.service;

public interface UserService {

    public void show();

}
