package com.itheima.dao;

public interface PersonDao {
}
