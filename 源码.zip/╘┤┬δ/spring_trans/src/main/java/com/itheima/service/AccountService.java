package com.itheima.service;

public interface AccountService {

    void transferAccount(String outAccount,String inAccount,Integer money);

}
