package com.itheima.test;

public class Target {

    public void show(){
        System.out.println("show..");
    }


}
